//
//  AuthViewController.swift
//  TestCocoaPods
//
//  Created by Гость on 13.04.2022.
//

import UIKit
import SwiftyJSON
import Alamofire

class AuthViewController: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func authAction(_ sender: Any) {
        if !(loginTextField.text!.isEmpty) && !(passwordTextField.text!.isEmpty) {
            let login = self.loginTextField.text!
            let password = self.passwordTextField.text!
            let url = "http://mad2019.hakta.pro/api/login/?login=\(login)&password=\(password)"
            AF.request(url, method: .get).validate().responseJSON { response in
                switch response.result {
                case .success(let value):
                    let json = JSON(value)
                    self.alertControllers(title: "Успех", description: "Вы успешно авторизовались")
                    print("JSON: \(json)")
                case .failure(let error):
                    print(error)
                    self.alertControllers(title: "Ошибка", description: "Пользователь с таким логином не найден")
                }
            }
        }else{
            
            alertControllers(title: "Ошибка", description: "Вы не ввели логин или пароль.")
            
        }
        
        
    }
    
    @IBAction func goBackAction(_ sender: Any) {
        if loginTextField.text!.isEmpty && passwordTextField.text!.isEmpty {
            performSegue(withIdentifier: "openMainView", sender: self)
        }else{
            alertControllers(title: "Ошибка", description: "Для перехода поля ввода должна быть пустым")
        }
    }
    
    func alertControllers(title: String, description: String) {
        passwordTextField.text = ""
        let alert = UIAlertController(title: title, message: description, preferredStyle: .alert)
        let closeAction = UIAlertAction(title: "Закрыть", style: .cancel, handler: nil)
        alert.addAction(closeAction)
        present(alert, animated: true, completion: nil)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
